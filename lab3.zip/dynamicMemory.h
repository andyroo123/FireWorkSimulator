/* Andrew Kolarits */

struct firework* newAllocateData(void *data, unsigned int hexValue, int currSizeOfList);
void unallocateFirework(void *data);
